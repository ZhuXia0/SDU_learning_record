package site.laoc.forum.net;

public interface OnImageRes {
    public void onSucess(ImgResult result);
    public void onFailure(ImgResult result);
}
