package site.laoc.forum.net;

public class ImgResData {
    private Integer ExistFace;

    public Integer getExistFace() {
        return ExistFace;
    }

    public void setExistFace(Integer existFace) {
        ExistFace = existFace;
    }
}
