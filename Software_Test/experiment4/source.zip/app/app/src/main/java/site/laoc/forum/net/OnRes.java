package site.laoc.forum.net;

public interface OnRes {
    public void onSucess(Result result);
    public void onFailure(Result result);
}
