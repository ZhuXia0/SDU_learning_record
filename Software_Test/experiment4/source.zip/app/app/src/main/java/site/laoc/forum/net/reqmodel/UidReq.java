package site.laoc.forum.net.reqmodel;

public class UidReq {
    private String uid;

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }
}
