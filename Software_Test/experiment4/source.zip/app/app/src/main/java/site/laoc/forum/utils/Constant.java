package site.laoc.forum.utils;

public class Constant {
    //public static final String BASE_URL = "http://192.168.0.5:8080/app/";

    public static final String BASE_URL = "http://211.87.232.162:8080/app/";
}
