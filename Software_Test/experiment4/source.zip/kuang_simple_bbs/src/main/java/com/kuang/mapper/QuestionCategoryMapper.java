package com.kuang.mapper;

import com.kuang.pojo.QuestionCategory;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author 遇见狂神说
 * @since 2020-06-28
 */
public interface QuestionCategoryMapper extends BaseMapper<QuestionCategory> {

}
