package com.kuang.service;

import com.kuang.pojo.QuestionCategory;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author 遇见狂神说
 * @since 2020-06-28
 */
public interface QuestionCategoryService extends IService<QuestionCategory> {

}
