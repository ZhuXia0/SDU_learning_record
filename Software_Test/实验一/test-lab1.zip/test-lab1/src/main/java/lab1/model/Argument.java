package lab1.model;

/**
 * 字符串类型的参数。
 */
public class Argument {
  private String value;

  public String getValue() {
    return value;
  }

  public void setValue(String value) {
    this.value = value;
  }
}
