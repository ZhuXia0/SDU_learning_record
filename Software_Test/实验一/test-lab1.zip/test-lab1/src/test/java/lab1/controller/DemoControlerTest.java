package lab1.controller;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(DemoController.class)
class DemoControllerTest {
  @Autowired
  private MockMvc mockMvc;  // 模拟 HTTP 请求

  @Test
  void testIndex() throws Exception {
    mockMvc.perform(get("/"))
      .andExpect(status().isOk())
      .andExpect(jsonPath("$.code").value("OK"));
  }

  @Test
  void testDecToHex() throws Exception {
    mockMvc.perform(get("/dec-to-hex"))
      .andExpect(status().is4xxClientError());

    mockMvc.perform(post("/dec-to-hex"))
      .andExpect(status().is5xxServerError()); // 这里期望会落空，测试失败。
  }
}
