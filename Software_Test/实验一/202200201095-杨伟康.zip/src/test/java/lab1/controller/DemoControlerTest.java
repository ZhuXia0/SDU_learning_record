package lab1.controller;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(DemoController.class)
class DemoControllerTest {
  @Autowired
  private MockMvc mockMvc;

  @Test
  void testIndex() throws Exception {
    mockMvc.perform(get("/"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.code").value("OK"));
  }

  @Test
  void testDecToHex_NormalInput() throws Exception {
    // 测试正常输入123 → 7b
    mockMvc.perform(post("/dec-to-hex")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content("{\"value\":\"123\"}"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.code").value("OK"))
            .andExpect(jsonPath("$.data.hex").value("7b"));

    // 测试边界值0 → 0
    mockMvc.perform(post("/dec-to-hex")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content("{\"value\":\"0\"}"))
            .andExpect(jsonPath("$.data.hex").value("0"));

    // 测试255 → ff
    mockMvc.perform(post("/dec-to-hex")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content("{\"value\":\"255\"}"))
            .andExpect(jsonPath("$.data.hex").value("ff"));
  }

  @Test
  void testDecToHex_NegativeInput() throws Exception {
    // 测试负数输入
    mockMvc.perform(post("/dec-to-hex")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content("{\"value\":\"-1\"}"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.data.hex").exists());

    // 测试大负数
    mockMvc.perform(post("/dec-to-hex")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content("{\"value\":\"-255\"}"))
            .andExpect(jsonPath("$.data.hex").exists());
  }

  @Test
  void testDecToHex_InvalidInput() throws Exception {
    // 测试非数字输入
    mockMvc.perform(post("/dec-to-hex")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content("{\"value\":\"abc\"}"))
            .andExpect(status().isBadRequest());

    // 测试空输入
    mockMvc.perform(post("/dec-to-hex")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content("{\"value\":\"\"}"))
            .andExpect(status().isBadRequest());

    // 测试缺少value字段
    mockMvc.perform(post("/dec-to-hex")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content("{}"))
            .andExpect(status().isBadRequest());
  }

  @Test
  void testCalc_SimpleOperations() throws Exception {
    // 测试简单加法 1 + 2 = 3
    mockMvc.perform(post("/calc")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content("{\"value\":\"1 + 2\"}"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.data.result").value(3));

    // 测试减法 5 - 2 = 3
    mockMvc.perform(post("/calc")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content("{\"value\":\"5 - 2\"}"))
            .andExpect(jsonPath("$.data.result").value(3));

    // 测试乘法 3 * 4 = 12
    mockMvc.perform(post("/calc")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content("{\"value\":\"3 * 4\"}"))
            .andExpect(jsonPath("$.data.result").value(12));

    // 测试除法 10 / 2 = 5
    mockMvc.perform(post("/calc")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content("{\"value\":\"10 / 2\"}"))
            .andExpect(jsonPath("$.data.result").value(5));
  }

  @Test
  void testCalc_OperatorPrecedence() throws Exception {
    // 测试运算符优先级 1 + 2 * 3 = 7
    mockMvc.perform(post("/calc")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content("{\"value\":\"1 + 2 * 3\"}"))
            .andExpect(jsonPath("$.data.result").value(7));

    // 测试复杂表达式 3 * 4 - 2 = 10
    mockMvc.perform(post("/calc")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content("{\"value\":\"3 * 4 - 2\"}"))
            .andExpect(jsonPath("$.data.result").value(10));

    // 测试多运算符 1 + 2 * 3 - 4 / 2 = 5
    mockMvc.perform(post("/calc")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content("{\"value\":\"1 + 2 * 3 - 4 / 2\"}"))
            .andExpect(jsonPath("$.data.result").value(5));
  }

  @Test
  void testCalc_SingleOperand() throws Exception {
    // 测试单操作数 1 = 1
    mockMvc.perform(post("/calc")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content("{\"value\":\"1\"}"))
            .andExpect(jsonPath("$.data.result").value(1));

    // 测试大数单操作数
    mockMvc.perform(post("/calc")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content("{\"value\":\"123456789\"}"))
            .andExpect(jsonPath("$.data.result").value(123456789));
  }

  @Test
  void testCalc_InvalidExpressions() throws Exception {
    // 测试不完整表达式 1 +
    mockMvc.perform(post("/calc")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content("{\"value\":\"1 +\"}"))
            .andExpect(status().isBadRequest());

    // 测试非法字符 1 & 2
    mockMvc.perform(post("/calc")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content("{\"value\":\"1 & 2\"}"))
            .andExpect(status().isBadRequest());

    // 测试空表达式
    mockMvc.perform(post("/calc")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content("{\"value\":\"\"}"))
            .andExpect(status().isBadRequest());

    // 测试缺少value字段
    mockMvc.perform(post("/calc")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content("{}"))
            .andExpect(status().isBadRequest());
  }
}