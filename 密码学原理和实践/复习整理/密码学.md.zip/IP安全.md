# IP安全

认证角度，IP包的完整性，包头的完整性和负载的完整性

第一，IP包是真实的，是不是从正确的IP地址发过来的，

在IP层考虑，对IP包进行改造

​![image](assets/image-20241216111453-1vi8iht.png)​

IP安全（AH,ESP）

​![image](assets/image-20241216112026-e40aqc5.png)​
