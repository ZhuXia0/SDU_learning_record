# 认证加密和Kerberos

## 认证加密模式

​![image](assets/image-20241208192925-0w4nqro.png)​

### AES-GCM模式

​![image](assets/image-20241208192957-z6k3beq.png)​

​![image](assets/image-20241208193001-mej5d04.png)​

### AEAD

​![image](assets/image-20241208193651-8jys13b.png)​

这是一个密码学概念，指的是一种加密技术，它不仅能加密数据，还能对数据的完整性和真实性进行验证。这种技术通过同时提供加密和认证服务，增强了数据的安全性。AEAD算法允许用户附加一些非加密的关联数据（Associated Data，简称AD），这些数据在加密过程中不会被加密，但会被用于认证过程，以确保数据在传输过程中没有被篡改。

### 其他认证加密模式

​![image](assets/image-20241208193806-84aawmy.png)​

#### python的编程实现

## KERBEROS认证协议

​![image](assets/image-20241208193906-l1q4745.png)​![image](assets/image-20241208193915-yj2n0hi.png)​

​![image](assets/image-20241208193919-iv1a5n2.png)​

​![image](assets/image-20241208193931-cokgasj.png)​

​![image](assets/image-20241208193938-h6qurnq.png)​

​![image](assets/image-20241208193945-qden1zc.png)​
