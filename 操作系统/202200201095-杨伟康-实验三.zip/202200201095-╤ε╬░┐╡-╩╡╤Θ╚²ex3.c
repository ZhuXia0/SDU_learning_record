#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <signal.h>
#include <sched.h>
#include <sys/time.h>
#include <sys/resource.h>
static int flag = 0;
//加信号
void add(int sig)
{
    flag++;
    printf("优先数+1\n");
}
//减信号
void minus(int sig)
{
    flag--;
    printf("优先数-1\n");
}
int main()
{
    //绑定信号
    signal(SIGINT,add);
    signal(SIGTSTP,minus);
    int pid = fork();
    if(pid == 0)
    {
        while(1)
        {
            //设置进程的优先级
            setpriority(PRIO_PROCESS,getpid(),flag);
            //输出进程号
            printf("子进程 = %d\n",getpid());
            //输出优先级
            printf("子进程优先数 = %d\n",getpriority(PRIO_PROCESS,getpid()));
            //输出调度策略
            printf("子进程的调度策略 = %d\n",sched_getscheduler(getpid()));
            sleep(4);
        }
    }
    else if(pid > 0)
    {
        while(1)
        {
            //设置进程的优先级
            setpriority(PRIO_PROCESS,getpid(),flag);
            //输出进程号
            printf("父进程 = %d\n",getpid());
            //输出优先级
            printf("父进程优先数 = %d\n",getpriority(PRIO_PROCESS,getpid()));
            //输出调度策略
            printf("父进程的调度策略 = %d\n",sched_getscheduler(getpid()));
            sleep(4);
        }
    }
}

