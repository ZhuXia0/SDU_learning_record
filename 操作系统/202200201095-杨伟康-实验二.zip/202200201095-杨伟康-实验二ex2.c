/*
  设有二元函数 f(x,y) = f(x) + f(y) 
 
其中： f(x) = f(x-1) * x (x >1) 
f(x)=1 (x=1) 
f(y) = f(y-1) + f(y-2) (y> 2) 
f(y)=1 (y=1,2) 
 
 请编程建立 3 个并发协作进程，它们分别完成 f(x,y)、f(x)、f(y) 
 */
#include <stdio.h> 
#include <unistd.h> 
#include <stdlib.h> 
int main(int argc, char* argv[])
{
	int pidx,pidy; //进程号 
	int pipex[2]; //存放第一个无名管道标号 
	int pipey[2]; //存放第二个无名管道标号 
	int x; 
	int y;
	// 获取用户输入需要计算的数据

	printf("请输入整数x（x >= 1）：");
	scanf("%d", &x);
	// 检测输入x的合法性
	while (x < 1)
	{
		printf("错误！请重新输入整数x（x >= 1）：");
		scanf("%d", &x);
	}

	printf("请输入整数y（y >= 1）：");
	scanf("%d", &y);
	// 检测输入y的合法性
	while (y < 1)
	{
		printf("错误！请重新输入整数y（y >= 1）：");
		scanf("%d", &y);
	}

	// 存放要传递的整数 
	//使用 pipe()系统调用建立两个无名管道。建立不成功程序退出，执行终止 
	if (pipe(pipex) < 0) {
		perror("pipe not create");
		exit(EXIT_FAILURE);
	}
	if (pipe(pipey) < 0)
	{
		perror("pipe not create");
		exit(EXIT_FAILURE);
	}
	pidx = fork();
	//使用fork()系统调用建立子进程，建立不成功程序则退出，执行终止
	if (pidx< 0)
	{
		perror("process not create");
		exit(EXIT_FAILURE);
	}
	//子进程号等于零表示子进程执行，
	
	else if(pidx>0)//进程号大于0表示父进程执行
	{
		// 此时1号子进程已经创建成功，当前处在父进程控制下
		// 创造2号子进程
		// 在这里创建2号子进程的原因是防止在1号子进程中创建他的子进程
		pidy = fork();
		if (pidy < 0)
		{
			// 建立2号子进程失败
			printf("2号子进程创建失败！\n");
			exit(EXIT_FAILURE);
		}
		else if (pidy > 0)
			printf("子进程创建成功！\n"); // 此时在父进程中
	}
	if (pidx == 0)
	{// 1号子进程只打开1号通道的写入端
		close(pipex[0]);
		close(pipey[0]);
		close(pipey[1]);
		int result = fx(x);
		write(pipex[1], &result, sizeof(int)); // 向父进程发送结果
		close(pipex[1]); // 结束后关闭通道
		printf("子进程x计算完毕，发送给父进程\n");

	}
    if (pidy == 0 && pidx > 0)
	{// 1号子进程只打开1号通道的写入端
		close(pipex[0]);
		close(pipey[0]);
		close(pipex[1]);
		int result = fy(y);
		write(pipey[1], &result, sizeof(int)); // 向父进程发送结果
		close(pipey[1]); // 结束后关闭通道
		printf("子进程y计算完毕，发送给父进程\n");

	}

	if (pidx > 0 && pidy > 0)
	{
		// 此时在父进程中
		// 父进程仅接受来自2个子进程的数据
		close(pipex[1]);
		close(pipey[1]);
		// 接收结果
		int ansX, ansY;
		read(pipex[0], &ansX, sizeof(int));
		close(pipex[0]);
		read(pipey[0], &ansY, sizeof(int));
		close(pipey[0]);
		int result = ansX + ansY;
		printf("结果为：f(x) = %d; f(y) = %d; f(x, y) = %d\n", ansX, ansY, result);
		printf("运算结束！\n");
	}

	// 1号子进程处理f(x)

		
	
	return EXIT_SUCCESS;
	//父进程结束
	}
int fx(int x)
{
	if (x == 1)
		return 1;
	return  x + fx(x - 1);
}

// f(y)处理函数
int fy(int y)
{
	if (y == 1 || y == 2)
		return 1;
	return fy(y - 1) + fy(y - 2);
}


