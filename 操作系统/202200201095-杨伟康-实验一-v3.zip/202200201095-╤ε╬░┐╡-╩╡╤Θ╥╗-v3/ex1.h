#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
typedef void (*sighandler_t)(int);
//进程自定义的时间信号
void sigcat()
{
printf("\n父进程%d发送唤醒信号\n", getppid());
}
