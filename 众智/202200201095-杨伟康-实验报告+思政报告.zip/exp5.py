import numpy as np


# 得出一个群体对X和Y的偏好比较
def compare(X, Y, votes):
    m = len(votes)  # 投票人数
    numX, numY = 0, 0
    x = np.array(np.where(votes == X))
    y = np.where(votes == Y)
    for i in range(m):
        if x[1][i] < y[1][i]:
            numX += 1
        else:
            numY += 1
    return numX - numY


# 产生相应的有向图邻接矩阵
def matrix_generator(votes):
    n = len(votes[0])
    m = len(votes)
    matrix = np.zeros((n, n), dtype=int)
    for i in range(1, n+1):
        for j in range(i + 1, n+1):
            if compare(i, j, votes) > 0:
                matrix[i-1][j-1] = 1
            else:
                matrix[j-1][i-1] = 1
    return matrix


# 检验是否存在孔多塞悖论 如果删完所有节点则不存在
def check_condorcet(matrix):
    bool = True
    while bool == True:
        for i in range(len(matrix)):
            bool = False
            individual = matrix[:, i]
            flag = True
            for item in individual:
                if item > 0:
                    flag = False
                    break
            if flag == True:
                bool = True
                matrix = np.delete(matrix, i, 0)
                matrix = np.delete(matrix, i, 1)
                if len(matrix) == 0:
                    print('不存在孔多塞悖论')
                    return False
                break
    print('存在孔多塞悖论')
    return True


def sort_check(dict, s):
    selections = list(dict.keys())
    selections.sort()  # 便于后续遍历
    # 按位置的大小排序之后所对应的值应该等于关键值
    locations = list(dict.values())
    locations.sort()
    for i in range(len(selections)):
        if s == 'right':
            location = locations[i]
        if s == 'left':
            location = locations[len(locations) - i - 1]
        if dict[selections[i]] != location:
            return False
    return True


def single_peak_check(vote):
    n = len(vote)
    peak = vote[0]
    right = {}
    left = {}
    for i in range(peak + 1, n + 1):
        right[i] = list(vote).index(i)
    for i in range(1, peak):
        left[i] = list(vote).index(i)
    r = sort_check(right, 'right')
    l = sort_check(left, 'left')
    return r and l


def delete_vote(votes):
    invalid_votes = []
    for i in range(len(votes)):
        if single_peak_check(votes[i]) == False:
            invalid_votes.append(i)

    print('违反单峰性质的投票：')
    print(invalid_votes)
    votes = np.delete(votes, invalid_votes, 0)
    print("删除之后的剩余投票：")
    print(votes)


# 根据中位项定理排序
def mediansort(votes):
    prefer = []
    for vote in votes:
        prefer.append(vote[0])
    selsction, counts = np.unique(np.array(prefer), return_counts=True)
    frequence = dict(zip(selsction, counts))
    num = 0
    for middle in frequence.keys():
        num += frequence[middle]
        if num >= (len(votes) + 1) // 2:
            break
    return middle


def groupsort(votes):
    num0 = len(votes)
    print("最后的群体排序是：")
    while True:
        middle = mediansort(votes)
        print(middle, end=' ')
        num = len(votes[0])
        if num == 1:
            break
        num = num - 1
        votes = votes[votes != middle]
        votes = np.reshape(votes, (num0, num))


m = 10  # 投票人数
n = 3  # 候选项个数
# 隐含偏好顺序1.2.3…………
# 生成随机排名
rankings = []
for i in range(m):
    ranking = np.random.choice(range(1, n + 1), size=n, replace=False)
    rankings.append(list(ranking))

# 检查是否存在孔多塞悖论和单峰性质
rankings = np.array(rankings)
print(rankings)
delete_vote(rankings)
print('孔多塞排序有向图：\n', matrix_generator(rankings))
if check_condorcet(matrix_generator(rankings)):
    pass
else:
    groupsort(rankings)
