import numpy as np
import matplotlib.pyplot as plt
import matplotlib


N = 50
threshold = 0.7
figsize=(12,12)

x = np.arange(N)
y = np.arange(N)
X, Y = np.meshgrid(x, y)
status = ["blue", "red", 'white']
prob = [0.4, 0.4, 0.2]

def init_z():
    Z = np.random.choice(a=status, size=(N**2), p=prob)
    Z.shape = (N, N)
    return Z

Z = init_z()
def get_null_cells(Z):
    """获取空白格子的位置
    Z:np.array, N*N
    return:list of cells position
    """
    if not Z.shape == (N, N):
        Z.shape = (N, N)
    cells = np.where(Z == "white")
    return cells

def get_cell_satisfaction(Z, row, col):

    if not Z.shape == (N, N):
        Z.shape = (N, N)
    if Z[row, col] == "white":
        return np.nan
    same, count = 0, 0
    left = 0 if col==0 else col-1
    right = Z.shape[1] if col==Z.shape[1]-1 else col+2
    top = 0 if row==0 else row-1
    bottom = Z.shape[0] if row==Z.shape[0]-1 else row+2
    for i in range(top, bottom):
        for j in range(left, right):
            if (i, j) == (row, col) or Z[i,j] == "white":
                continue
            elif Z[i, j] == Z[row, col]:
                same += 1
                count += 1
            else:
                count += 1
    if not count == 0:
        satisfaction = same / count
    else:
        satisfaction = 0
    return satisfaction

def get_all_satisfaction(Z):
    """得到所有格子的满意度
    return: np.array N*N
    """
    satis_scores = []
    for row in range(Z.shape[0]):
        for col in range(Z.shape[1]):
            # print(row, col)
            satis_scores.append(get_cell_satisfaction(Z, row, col))
    satis_scores = np.array(satis_scores)
    satis_scores.shape = Z.shape
    return satis_scores

def satis_mean(Z):
    """所有格子的平均满意度
    return: res -> int
    """
    satis_scores = get_all_satisfaction(Z)
    res = satis_scores[np.where(satis_scores>=0)].mean()
    return res

def get_dissatis_cells(Z=Z, threshold=threshold):
    """得到不满意的格子
    return: tuple 2 items
    """
    satis_scores = get_all_satisfaction(Z)
    res = np.where(satis_scores < threshold)
    return res

def dissatis_ratio(Z):
    satis_scores = get_all_satisfaction(Z)
    res = np.sum(satis_scores<threshold) / np.sum(satis_scores>=0)
    return res

def move(Z):
    dissatis_cells = get_dissatis_cells()
    for i in range(len(dissatis_cells[0])):
        blank_cells = get_null_cells(Z)
        dissatis_row = dissatis_cells[0][i]
        dissatis_col = dissatis_cells[1][i]
        j = np.random.choice(range(len(blank_cells[0])))
        blank_row = blank_cells[0][j]
        blank_col = blank_cells[1][j]
        Z[dissatis_row, dissatis_col], Z[blank_row, blank_row] = Z[blank_row, blank_row], Z[dissatis_row, dissatis_col]
def draw_raw(Z):
    fig = plt.figure(figsize=figsize)
    ax = fig.add_subplot(111)
    ax.scatter(X, Y, marker='s', c=Z.ravel(), s=80, lw=0, ec='w')
    ax.set_facecolor((.85,.85,.85))
    ax.invert_yaxis()
    ax.set(title=f"random distribution of 3 kind cells (blank cells ratio {prob[-1]*100}%)")
    ax.set(xlabel=f"blue={np.sum(Z=='blue')},  red={np.sum(Z=='red')},  WHITE={np.sum(Z=='white')}")
    ax.set(xlabel=f"threshold={threshold}, satisfactions_mean={satis_mean(Z)*100:0.2f}%, dissatisfaction_ratio={dissatis_ratio(Z)*100:0.2f}%")
    plt.show()

def draw_nullcells(Z):
    null_cells = get_null_cells(Z)
    fig = plt.figure(figsize=figsize)
    ax = fig.add_subplot(111)
    ax.invert_yaxis()
    ax.set_facecolor((.85,.85,.85))
    ax.scatter(X, Y, marker='s', c='.7', s=80, lw=0, ec='w')
    ax.scatter(null_cells[1], null_cells[0], marker='s', c='k', s=80, lw=0, ec='w')
    # 随机选一个格子搬家
    rn = np.random.choice(range(len(null_cells[0])))
    ax.scatter(null_cells[1][rn], null_cells[0][rn], marker='s', c='r', s=200, lw=0, ec='w')
    ax.set(title=f"blank cells({len(null_cells[0])}) and a random blank one")
    ax.set(xlabel=f"blank cell ratio={np.sum(Z=='white') / N**2 * 100}%")

    plt.show()


def draw_satisfaction(Z):
    satis_scores = get_all_satisfaction(Z)

    fig = plt.figure(figsize=figsize)
    ax = fig.add_subplot(111)
    ax.invert_yaxis()
    ax.set_facecolor((.85,.85,.85))

    ax.scatter(X, Y, marker='s', c='.7', s=80, lw=0, ec='w')
    scatter1 = ax.scatter(X, Y, marker='s', c=satis_scores, s=80, lw=0, ec='w')
    plt.colorbar(scatter1)
    ax.set(title="cell's satisfaction scores")
    ax.set(xlabel=f"threshold={threshold}, satisfactions_mean={satis_mean(Z)*100:0.2f}%, dissatisfaction_ratio={dissatis_ratio(Z)*100:0.2f}%")
    plt.show()

def draw_dissatiscells(Z):
    dissatis_cells = get_dissatis_cells()

    fig = plt.figure(figsize=figsize)
    ax = fig.add_subplot(111)
    ax.invert_yaxis()
    ax.set_facecolor((.85,.85,.85))

    ax.scatter(X, Y, marker='s', c='.7', s=80, lw=0, ec='w')
    ax.scatter(dissatis_cells[1], dissatis_cells[0], marker='s', c='r', s=80, lw=0, ec='w')
    ax.set(title=f"dissatisfaction cells({len(dissatis_cells[0])})")
    ax.set(xlabel=f"threshold={threshold}, dissatisfaction_ratio={dissatis_ratio(Z)*100:0.2f}%")

    plt.show()

def draw_moves_inplace(Z, times=0):
    fig = plt.figure(figsize=figsize)
    ax = fig.add_subplot(111)
    for i in range(times):
        move(Z)
    ax.scatter(X, Y, marker='s', c=Z.ravel(), s=80, lw=0, ec='w')
    ax.set(title=f"after {times} times, dissatisfaction_ratio = {dissatis_ratio(Z)*100:0.2f}")
    ax.set_facecolor((.85,.85,.85))
    ax.invert_yaxis()
    ax.set(xlabel=f"threshold={threshold}, satisfactions_mean={satis_mean(Z)*100:0.2f}%, dissatisfaction_ratio={dissatis_ratio(Z)*100:0.2f}%")
    plt.show()




draw_raw(Z)
draw_nullcells(Z)
draw_satisfaction(Z)
draw_dissatiscells(Z)
draw_moves_inplace(Z, 10)
draw_moves_inplace(Z, 100)
draw_moves_inplace(Z, 1000)
draw_dissatiscells(Z)
