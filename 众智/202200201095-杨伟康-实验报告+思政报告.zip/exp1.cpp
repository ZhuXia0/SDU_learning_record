#include<iostream>
#include<algorithm>
#include<cstring>
#include <cstdlib> // 包含rand()和srand()  
#include <ctime>   // 包含time()
using namespace std;
//友谊悖论大多数节点的度数小于邻居节点的平均度数
int n;

const int N=10100;
int friends[N][N];
int fdnb[N];
double data[N];
int main()
{
while(true)
{    cout<<"请输入社会网络中的结点数："<<endl;
    cin>>n;
    for(int t=0;t<10;t++)
{
    for(int i=1;i<=n;i++)
    {
        for(int j=i+1;j<=n;j++)
        {
            friends[i][j]=rand()%2;
            friends[j][i]=friends[i][j];
        }
    }
    for(int i=1;i<=n;i++)
    {
        int nb=0;
        for(int j=1;j<=n;j++)
        {
            if(friends[i][j]==1&&i!=j)nb++;
        }
        fdnb[i]=nb;
    }
    int res=0;
    for(int i=1;i<=n;i++)
    {
        double sum=0;
        for(int j=1;j<=n;j++)
        {
           if(i!=j&&friends[i][j]==1)
           {
                sum+=fdnb[j];
           }
        }
        if(fdnb[i]<sum/fdnb[i])res++;
    }
    data[t]=(double)res/n;
}
    double sum=0;
    for(int i=0;i<10;i++)
    {
        sum+=data[i];
    }
    double aver = sum/10;
    cout<<"符合友谊悖论的概率是："<<aver<<endl;}
    return 0;
}