import random
import networkx as nx
import matplotlib.pyplot as plt
import os

# 初始化网络结构和参数
G = nx.karate_club_graph()  # 示例网络，可以使用其他网络结构
initial_nodes = [0, 1]  # 初始节点集合
threshold = 2  # 门槛值
delay_distribution = lambda: random.randint(1, 3)  # 延时分布（1到3之间的随机整数）

# 固定随机种子以确保可重复性
random_seed = 42   # 选择一个固定的种子值

# 初始化状态和时间字典
state = {node: 'unaccepted' for node in G.nodes()}
acceptance_time = {node: float('inf') for node in G.nodes()}
for node in initial_nodes:
    state[node] = 'accepted'
    acceptance_time[node] = 0

# 模拟扩散过程
queue = initial_nodes[:]
step = 0  # 用于记录步骤的变量

# 确保保存图片的目录存在
output_dir = 'diffusion_steps'
if not os.path.exists(output_dir):
    os.makedirs(output_dir)

while queue:
    current_node = queue.pop(0)
    for neighbor in G.neighbors(current_node):
        if state[neighbor] == 'unaccepted' and sum(
                1 for n in G.neighbors(neighbor) if state[n] == 'accepted') >= threshold:
            state[neighbor] = 'processing'
            delay = delay_distribution()
            acceptance_time[neighbor] = acceptance_time[current_node] + delay if acceptance_time[current_node] != float(
                'inf') else delay
            state[neighbor] = 'accepted'
            queue.append(neighbor)

            # 可视化当前步骤
            fig, ax = plt.subplots()
            pos = nx.spring_layout(G, seed=random_seed)
            nx.draw_networkx_nodes(G, pos, nodelist=[node for node in G.nodes() if state[node] == 'accepted'],
                                   node_color='green')
            nx.draw_networkx_nodes(G, pos, nodelist=[node for node in G.nodes() if state[node] == 'unaccepted'],
                                   node_color='red')
            nx.draw_networkx_edges(G, pos)
            nx.draw_networkx_labels(G, pos)

            # 保存当前步骤的图片
            step_filename = os.path.join(output_dir, f'step_{step:03d}.png')
            plt.savefig(step_filename)
            plt.close(fig)  # 关闭图形，释放资源

            step += 1

        # 计算延时和平均延时
delays = [acceptance_time[node] - min(
    acceptance_time[n] for n in G.neighbors(node) if state[n] == 'accepted' and acceptance_time[n] != float('inf'))
          if state[node] == 'accepted' and acceptance_time[node] != float('inf') else 0
          for node in G.nodes()]
average_delay = sum(delays) / len(delays) if delays else 0

print("Delays:", delays)
print("Average Delay:", average_delay)