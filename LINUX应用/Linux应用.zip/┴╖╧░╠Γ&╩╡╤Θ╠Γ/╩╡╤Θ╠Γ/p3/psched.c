#include <stdio.h>
#include <signal.h>
#include <sys/types.h>
#include <unistd.h>
#include <wait.h>
#include <stdlib.h>
#include <sched.h>
#include <sys/time.h>
#include <sys/resource.h>

void dealc(int sig) 
{
    setpriority(PRIO_PROCESS,getpid(),getpriority(PRIO_PROCESS,0)+1);
}

void dealz(int sig) 
{
    setpriority(PRIO_PROCESS,getpid(),getpriority(PRIO_PROCESS,0)-1);
}

void deal(int sig){}

int main(int argc, char *argv[])
{
	int i;

	int pid; //存放进程号

	//创建子进程

	pid=fork();

	if(pid<0)
	{
		printf("Create Process fail!\n");
		exit(EXIT_FAILURE);
	}

	//子进程循环报告其优先数和调度策略

	else if(pid==0)
	{
  		sleep(2);



  		int b=0;
  		setpriority(PRIO_PROCESS,getpid(),SCHED_OTHER);
  		signal(SIGTSTP,dealz);
  		signal(SIGINT,deal);

  		//每隔2秒报告一次进程号和优先级
  		for(i=0; i<100; i++)
		{ 
    			printf("子进程= %d 优先级= %d 调度策略=%d\n",getpid(),getpriority(PRIO_PROCESS,0),sched_getscheduler(getpid()));

    			sleep(2);
  		}
   		exit( EXIT_SUCCESS);
  	}

	//父进程执行代码
	else
	{
  		sleep(2);
  		setpriority(PRIO_PROCESS,getpid(),SCHED_OTHER);
  		signal(SIGINT,dealc);
  		signal(SIGTSTP,deal);
  		//每隔2秒报告一次进程号和优先级
  		for(i=0; i<100; i++)
		{
  			printf("父进程= %d 优先级= %d 调度策略=%d\n ",getpid(),getpriority(PRIO_PROCESS,0),sched_getscheduler(getpid()));

  			sleep(2);
  		}
   		exit( EXIT_SUCCESS);

	}
}











