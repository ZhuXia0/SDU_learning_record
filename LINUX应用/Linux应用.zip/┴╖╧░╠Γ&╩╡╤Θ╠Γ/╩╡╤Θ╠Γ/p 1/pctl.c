#include "pctl.h"
int main(int argc,char *argv[]){
int i;
int pid1,pid2;
int status1,status2;
char *args1[]={"/bin/ls","-a",NULL};
char *args2[]={"/bin/ps","-a",NULL};
signal(SIGINT,(sighandler_t)sigcat);

pid1=fork();
//printf("I am the first Child process %d\n",getpid());
if(pid1<0){
printf("Create Process fail!\n");
exit(EXIT_FAILURE);}
if(pid1==0){
printf("I am the first child process %d :ls -a \n My father is %d \n",getpid(),getppid());
pause();
printf("%d child will Running:\n",getpid());

status1=execve(args1[0],args1,NULL);
}
else{
pid2=fork();
//printf("I am the second Child process %d\n",getpid());
if(pid2<0){
printf("Create Process fail!\n");
exit(EXIT_FAILURE);}
if(pid2==0){
printf("I am the second chhild process %d :ps -a \n My father is %d \n",getpid(),getppid());
status2=execve(args2[0],args2,NULL);
}

else{
//printf("\n I am parent process %d\n",getpid());
waitpid(pid2,&status2,0);
if(kill(pid1,SIGINT)>=0){
printf("%d Wakeup %d child. \n",getpid(),pid1);
printf("%d don't wait for child done.\n\n",getpid());}
}
}


return EXIT_SUCCESS;
}
