#include "OneWay.h"
#include <time.h>
Sema::Sema(int id)
{
sem_id = id;
}
Sema::~Sema(){ }
/*
* 信号灯上的 down/up 操作
* semid:信号灯数组标识符
* semnum:信号灯数组下标
* buf:操作信号灯的结构
*/
int Sema::down()
{
struct sembuf buf;
buf.sem_op = -1;
buf.sem_num = 0;
buf.sem_flg = SEM_UNDO;
if((semop(sem_id,&buf,1)) <0) {
perror("down error ");
exit(EXIT_FAILURE);
}
return EXIT_SUCCESS;
}

int Sema::up()
{
Sem_uns arg;
struct sembuf buf;
buf.sem_op = 1;
buf.sem_num = 0;
buf.sem_flg = SEM_UNDO;
if((semop(sem_id,&buf,1)) <0) {
perror("up error ");
exit(EXIT_FAILURE);
}
return EXIT_SUCCESS;
}
/*
* 用于管程的互斥执行
*/
Lock::Lock(Sema * s)
{
sema = s;
}
Lock::~Lock(){ }
//上锁
void Lock::close_lock()
{
sema->down();
}
//开锁
void Lock::open_lock()
{
sema->up();
}
//用于问题的条件变量
Condition::Condition(Sema *sema1 , Sema *sema2){
queue1 =sema1;
queue2 =sema2;
}
/*
* get_ipc_id() 从/proc/sysvipc/文件系统中获取 IPC 的 id 号
* pfile: 对应/proc/sysvipc/目录中的 IPC 文件分别为
*
msg-消息队列,sem-信号量,shm-共享内存
* key: 对应要获取的 IPC 的 id 号的键值
*/
int OneWay::get_ipc_id(char *proc_file,key_t key)
{
#define BUFSZ 256
FILE *pf;
int i,j;
char line[BUFSZ],colum[BUFSZ];
if((pf = fopen(proc_file,"r")) == NULL){
perror("Proc file not open");
exit(EXIT_FAILURE);
}
fgets(line, BUFSZ,pf);
while(!feof(pf)){
i = j = 0;
fgets(line, BUFSZ,pf);
while(line[i] == ' ') i++;
while(line[i] !=' ') colum[j++] = line[i++];
colum[j] = '\0';
if(atoi(colum) != key) continue;
j=0;
while(line[i] == ' ') i++;
while(line[i] !=' ') colum[j++] = line[i++];
colum[j] = '\0';
i = atoi(colum);
fclose(pf);
return i;
}
fclose(pf);
return -1;
}
/*
*
set_sem 函数建立一个具有 n 个信号灯的信号量
*
如果建立成功,返回 一个信号量的标识符 sem_id
*
输入参数:
*
sem_key 信号量的键值
*
sem_val 信号量中信号灯的个数
*
sem_flag 信号量的存取权限
*/
int OneWay::set_sem(key_t sem_key,int sem_val,int sem_flg)
{
int sem_id;
Sem_uns sem_arg;
//测试由 sem_key 标识的信号量是否已经建立
if((sem_id=get_ipc_id("/proc/sysvipc/sem",sem_key)) < 0 ){
//semget 新建一个信号灯,其标号返回到 sem_id
if((sem_id = semget(sem_key,1,sem_flg)) < 0){
perror("semaphore create error");
exit(EXIT_FAILURE);
}
}
//设置信号量的初值
sem_arg.val = sem_val;
if(semctl(sem_id,0,SETVAL,sem_arg) < 0){
perror("semaphore set error");
exit(EXIT_FAILURE);
}
return sem_id;
}
/*
*
set_shm 函数建立一个具有 n 个字节 的共享内存区
*
如果建立成功,返回 一个指向该内存区首地址的指针 shm_buf
*
输入参数:
*
shm_key 共享内存的键值
*
shm_val 共享内存字节的长度
*
shm_flag 共享内存的存取权限
*/
int * OneWay::set_shm(key_t shm_key,int shm_num,int shm_flg)
{
int i,shm_id;
int * shm_buf;
//测试由 shm_key 标识的共享内存区是否已经建立
if((shm_id=get_ipc_id("/proc/sysvipc/shm",shm_key))<0){
//shmget 新建 一个长度为 shm_num 字节的共享内存
if((shm_id= shmget(shm_key,shm_num,shm_flg)) <0){
perror("shareMemory set error");
exit(EXIT_FAILURE);
}
//shmat 将由 shm_id 标识的共享内存附加给指针 shm_buf
if((shm_buf=(int *)shmat(shm_id,0,0)) < (int *)0){
perror("get shareMemory error");
exit(EXIT_FAILURE);
}
for(i=0; i<shm_num; i++) shm_buf[i] = 0; //初始为 0
}
//共享内存区已经建立,将由 shm_id 标识的共享内存附加给指针 shm_buf
if((shm_buf = (int *)shmat(shm_id,0,0)) < (int *)0) {
perror("get shareMemory error");
exit(EXIT_FAILURE);
}
return shm_buf;
}

void Condition::Wait( Lock *conditionLock,int direct)
{
//保存当前条件锁;
lock=conditionLock;
//释放锁;
lock->open_lock();
//进入所在方向等待队列睡眠;
if(direct==1)
{
printf("%d 号车向东等待单行道\n",getpid());
queue1->down();
//printf("%d ----down------",queue1->down());
}
if(direct==2)
{
printf("%d 号车向西等待单行道\n",getpid());
queue2->down();
//printf("%d ----down------",queue2->down());
}
//被唤醒后重新获取锁;
lock->close_lock();
}
void Condition::Signal( Lock *conditionLock,int direct)
{
//printf("-------%d\n",direct);
lock=conditionLock;
lock->open_lock();
printf("-------%d\n",direct);
//唤醒相反方向队列等待者
if(direct==1)
{
printf("wake 1\n");
queue1->up();
}
if(direct==2)
{
printf("wake 2\n");
queue2->up();
}
lock->close_lock();//获取管程锁;

}
OneWay::OneWay(int r,int m)
{
maxCars=m;
rate = r;
int ipc_flg = IPC_CREAT | 0644;
int shm_key_n=501;
int shm_key_d=502;
int shm_num = 1;
int sem_key=320;
int sem_key_1 = 120;
int sem_key_2 =220;
int sem_val = 0;
int sem_id;
int sem_id_1;
int sem_id_2;
Sema *sema;
Sema *sema1;
Sema *sema2;

if((numCars=(int *)set_shm(shm_key_n,shm_num,ipc_flg)) == NULL){
perror("Share memory create error");
exit(EXIT_FAILURE);
}
numCars[0]=0;//初始值
if((currentDirec=(int *)set_shm(shm_key_d,shm_num,ipc_flg)) == NULL){
perror("Share memory create error");
exit(EXIT_FAILURE);
}
currentDirec[0]=1;//初始方向东
//建立一个初值为 1 的用于锁的信号灯
if((sem_id = set_sem(sem_key,1,ipc_flg)) < 0){
perror("Semaphor create error");
exit(EXIT_FAILURE);
}
sema = new Sema(sem_id);
lock = new Lock(sema);
//两个不同行驶方向用于条件变量的信号灯
if((sem_id_1 = set_sem(sem_key_1,0,ipc_flg)) < 0){
perror("Semaphor create error");
exit(EXIT_FAILURE);
}
if((sem_id_2 = set_sem(sem_key_2,0,ipc_flg)) < 0){
perror("Semaphor create error");
exit(EXIT_FAILURE);
}
sema1 = new Sema(sem_id_1);
sema2 = new Sema(sem_id_2);
OneWayFull= new Condition(sema1,sema2);
}

OneWay::~OneWay(){};

//单行道管程的 Arrive 和 Quit 方法:
void OneWay::Arrive(int direc)
{
lock->close_lock();//获取管程锁;
//如果当前方向不是我的方向或者单行道上有车且车辆数大于等于上限数
printf("ARRIVE PROCESS%dnumcars=%d,\n",getpid(),numCars[0]);
while(direc!=currentDirec[0] || numCars[0]>=maxCars)
{
//在条件变量上等待;
OneWayFull->Wait(lock,direc);
}
//单行道上车辆数加 1;
numCars[0]++;
if(direc==1)
{
printf("%d 号车向东进入单行道\n",getpid());
}
else
{
printf("%d 号车向西进入单行道\n",getpid());
}
//当前方向为我的方向;
currentDirec[0]=direc;
sleep(1);
//释放管程锁;
lock->open_lock();
}

void OneWay::Cross(int direc)
{
  if(direc==1)
  printf("%d 号车向东通过单行道，道上车数：%d\n",getpid(),numCars[0]);
  else
  printf("%d 号车向西通过单行道，道上车数：%d\n",getpid(),numCars[0]);
   sleep(rate);
}

void OneWay::Quit(int direc)
{
lock->close_lock();//获取管程锁;
if(direc==1)
{
printf("%d 号车向东离开单行道\n",getpid());
}
else
{
printf("%d 号车向西离开单行道\n",getpid());
}
numCars[0]--;//单行道上车辆数减 1;
printf("QUIT PROCESS%dnumcars=%d---%d,\n",getpid(),numCars[0],direc);
if(numCars[0]==0)//车辆数为 0
{
//唤醒相反方向队列中的等待者
    if(direc==1)
     {
	   OneWayFull->Signal(lock,2);
	   currentDirec[0]=2;
	 }
    if(direc==2)
     {
	   OneWayFull->Signal(lock,1);
	   currentDirec[0]=1;
	 }
}

 lock->open_lock();//释放管程锁
}
//主程序
main(int argc,char *argv[])
{
int rate=5;
int carnum;
int max;
carnum=(argc>1)?atoi(argv[1]):5;
max=(argc>1)?atoi(argv[2]):1;
int pid[carnum];
int direc;
//建立单行道管程;
OneWay *ow;
ow=new OneWay(rate,max);
//srand(time(NULL)); 
//建立多个行车子进程(最好不少于 5 个),每个随机设定一个行车方向;
for(int i=0;i<carnum;i++)
{
   //每个子进程作:
   if((pid[i]=fork())==0)
   {  
     // direc=rand()%2+1;
        direc=i%2+1;
        ow->Arrive(direc);
        ow->Cross(direc);
        ow->Quit(direc);
        exit(0);
    }
}

    return 0;
}

