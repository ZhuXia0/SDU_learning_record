   #include"ipc.h"   
   int main(int argc,char *argv[]){  
   int con_val=0;
   int rate;  
//可在在命令行第一参数指定一个进程睡眠秒数,以调解进程执行速度
   if(argv[1]!=NULL)rate=atoi(argv[1]);  
   else rate=3;  
//共享内存使用的变量
   buff_key=101;//缓冲区任给的键值  
   buff_num=2;  //缓冲区任给的长度
   pput_key=102;//生产者放产品指针的键值 
   pput_num=2;  //指针数
   shm_flg=IPC_CREAT|0644; //共享内存读写权限 
//获取缓冲区使用的共享内存,buff_ptr 指向缓冲区首地址
   buff_ptr=(char*)set_shm(buff_key,buff_num,shm_flg);  
//获取生产者放产品位置指针 pput_ptr
   pput_ptr=(int *)set_shm(pput_key,pput_num,shm_flg);  
//信号量使用的变量
   prod_key=201; //生产者同步信号灯键值 
   pmtx_key=202; //生产者互斥信号灯键值

   cig_key=301;  //消费者同步信号灯键值3

   pap_key=302;  //消费者1互斥信号灯键值
   glu_key=303;  //消费者2互斥信号灯键值
   smtx_key=304; //消费者3互斥信号灯键值
   sem_flg=IPC_CREAT|0644;  
//生产者互斥信号灯初值为 1
   sem_val=1;  
//获取生产者同步信号灯,引用标识存 prod_sem
   prod_sem=set_sem(prod_key,sem_val,sem_flg);  
//消费者初始无产品可取,同步信号灯初值设为 0
   sem_val=0;  
//三个信号量，分别控制烟草，纸张，胶水
   cig_sem=set_sem(cig_key,sem_val,sem_flg);  
   pap_sem=set_sem(pap_key,sem_val,sem_flg);  
   glu_sem=set_sem(glu_key,sem_val,sem_flg);  
   sem_val=1;  
   pmtx_sem=set_sem(pmtx_key,sem_val,sem_flg);  
//循环执行模拟生产者不断放产品
   while(1){  
//如果缓冲区满则生产者阻塞
     down(prod_sem);  
//如果另一生产者正在放产品,本生产者阻塞
     down(pmtx_sem);  
//用写一字符的形式模拟生产者放产品,报告本进程号和放入的字符及存放的位置
    if(con_val%3==0){  
        sleep(rate);  
        buff_ptr[*pput_ptr]='C';  
        *pput_ptr=(*pput_ptr+1)%buff_num;  
        buff_ptr[*pput_ptr]='P';  
        printf("供应商提供: 烟草T,纸张P\n");  
        sleep(rate);  
        } 
     else if(con_val%3==1){  
         sleep(rate);  
         buff_ptr[*pput_ptr]='C';  
        *pput_ptr=(*pput_ptr+1)%buff_num;  
        buff_ptr[*pput_ptr]='G';  
        printf("供应商提供: 胶水G,烟草T\n");  
        sleep(rate);  
        }  
          else{ sleep(rate);  
                buff_ptr[*pput_ptr]='P';  
               *pput_ptr=(*pput_ptr+1)%buff_num;  
                buff_ptr[*pput_ptr]='G';  
                printf("供应商提供: 纸张P,胶水G\n");   
                sleep(rate);  
               } 
//存放位置循环下移    
     *pput_ptr=(*pput_ptr+1)%buff_num; 
//唤醒阻塞的生产者 
       up(pmtx_sem);  
//唤醒阻塞的消费者
     if(con_val%3==0) up(glu_sem);  
     else if(con_val%3==1) up(pap_sem);  
          else up(cig_sem);  
    con_val=(con_val+1)%3;  
     }  
   return EXIT_SUCCESS;  

  }  
