#include"ipc.h"
int main(int argc,char *argv[]){
     int rate;
   if(argv[1]!=NULL)rate=atoi(argv[1]);
   else rate=3;
   buff_key=101;
   buff_num=2;
   pap_get_key=104;
   pap_get_num=2;
   shm_flg=IPC_CREAT|0644;
   buff_ptr=(char*)set_shm(buff_key,buff_num,shm_flg);
   pap_get_ptr=(int *)set_shm(pap_get_key,pap_get_num,shm_flg);
   prod_key=201;
   pmtx_key=202;
   pap_key=302;
   smtx_key=304;
   sem_flg=IPC_CREAT|0644;
   sem_val=1;
   prod_sem=set_sem(prod_key,sem_val,sem_flg);
   sem_val=0;   
   pap_sem=set_sem(pap_key,sem_val,sem_flg);  
   sem_val=1;   
   smtx_sem=set_sem(smtx_key,sem_val,sem_flg);  
   while(1){
        down(pap_sem);  
        down(smtx_sem);  
        sleep(1);
 printf("吸烟者有纸张P,取到胶水G,烟草 T.开始吸烟...\n");
   

     *pap_get_ptr=(*pap_get_ptr+2)%buff_num;   
        up(smtx_sem);
        up(prod_sem);   
       }
   return EXIT_SUCCESS;   
}   

