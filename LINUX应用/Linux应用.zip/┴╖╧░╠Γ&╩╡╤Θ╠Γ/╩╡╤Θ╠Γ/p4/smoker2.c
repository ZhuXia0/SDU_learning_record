#include"ipc.h"
int main(int argc,char *argv[]){
     int rate;
   if(argv[1]!=NULL)rate=atoi(argv[1]);
   else rate=3;
   buff_key=101;
   buff_num=2;
   glu_get_key=105;
   glu_get_num=2;
   shm_flg=IPC_CREAT|0644;
   buff_ptr=(char*)set_shm(buff_key,buff_num,shm_flg);
   glu_get_ptr=(int *)set_shm(glu_get_key,glu_get_num,shm_flg);
   prod_key=201;
   pmtx_key=202;
   glu_key=303;
   smtx_key=304;
   sem_flg=IPC_CREAT|0644;
   sem_val=1;
   prod_sem=set_sem(prod_key,sem_val,sem_flg);
   sem_val=0;
   glu_sem=set_sem(glu_key,sem_val,sem_flg);
   sem_val=1;
   smtx_sem=set_sem(smtx_key,sem_val,sem_flg);
   while(1){
        down(glu_sem);
        down(smtx_sem);
        sleep(1);
 printf("吸烟者有胶水G,取到烟草T,纸张 P.开始吸烟...\n");
      *glu_get_ptr=(*glu_get_ptr+2)%buff_num;
        up(smtx_sem);
        up(prod_sem);
       }
   return EXIT_SUCCESS;
}

