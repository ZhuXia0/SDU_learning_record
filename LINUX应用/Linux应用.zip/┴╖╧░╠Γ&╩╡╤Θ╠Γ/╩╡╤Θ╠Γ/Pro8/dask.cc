/*

1.1先来先服务算法(FCFS)

先来先服务(FCFS-First Come First Serve)算法，是一种随即服务算法，它不仅仅没有对寻找楼层进行优化，也没有实时性的特征，它是一种最简单的电梯调度算法。它根据乘客请求乘坐电梯的先后次序进行调度。此算法的优点是公平、简单，且每个乘客的请求都能依次地得到处理，不会出现某一乘客的请求长期得不到满足的情况[12]。这种方法在载荷较轻松的环境下，性能尚可接受，但是在载荷较大的情况下，这种算法的性能就会严重下降，甚至恶化。人们之所以研究这种在载荷较大的情况下几乎不可用的算法，有两个原因：
(1)任何调度算法在请求队列长度为1时，请求速率极低或相邻请求的间隔为无穷大时使用先来先服务算法既对调度效率不会产生影响，而且实现这种算法极其简单。
(2)先来先服务算法可以作为衡量其他算法的标准。
1.2最短寻找楼层时间优先算法(SSTF)

    最短寻找楼层时间优先(SSTF-Shortest Seek Time First) [14]算法，它注重电梯寻找楼层的优化。最短寻找楼层时间优先算法选择下一个服务对象的原则是最短寻找楼层的时间。这样请求队列中距当前能够最先到达的楼层的请求信号就是下一个服务对象。在重载荷的情况下，最短寻找楼层时间优先算法的平均响应时间较短，但响应时间的方差较大，原因是队列中的某些请求可能长时间得不到响应，出现所谓的“饿死”现象。
1.3扫描算法(SCAN)

扫描算法(SCAN)是一种按照楼层顺序依次服务请求，它让电梯在最底层和最顶层之间连续往返运行，在运行过程中响应处在于电梯运行方向相同的各楼层上的请求。它进行寻找楼层的优化，效率比较高，但它是一个非实时算法。扫描算法较好地解决了电梯移动的问题，在这个算法中，每个电梯响应乘客请求使乘客获得服务的次序是由其发出请求的乘客的位置与当前电梯位置之间的距离来决定的，所有的与电梯运行方向相同的乘客的请求在一次电向上运行或向下运行的过程中完成，免去了电梯频繁的来回移动[2]。
扫描算法的平均响应时间比最短寻找楼层时间优先算法长，但是响应时间方差比最短寻找楼层时间优先算法小，从统计学角度来讲，扫描算法要比最短寻找楼层时间优先算法稳定。
1.4 LOOK算法

LOOK算法[18]是扫描算法的一种改进。对LOOK算法而言，电梯同样在最底层和最顶层之间运行。但当LOOK算法发现电梯所移动的方向上不再有请求时立即改变运行方向，而扫描算法则需要移动到最底层或者最顶层时才改变运行方向。
1.5 SATF算法

SATF(Shortest Access Time First)[15,19]算法与SSTF算法的思想类似，唯一的区别就是SATF算法将SSTF算法中的寻找楼层时间改成了访问时间。这是因为电梯技术发展到今天，寻找楼层的时间已经有了很大地改进，但是电梯的运行当中等待乘客上梯时间却不是人为可以控制。SATF算法考虑到了电梯运行过程中乘客上梯时间的影响


*/
/*
* Filename
: dask.cc
* copyright
: (C) 2006 by zhonghonglie
* Function
: 磁盘移臂调度算法
*/
#include <iostream>
#include "dask.h"
#include <cstdlib>

using namespace std;

DiskArm::DiskArm(){
int i;
//输入当前道号
cout << "Please input Current cylinder :" ;
cin >> CurrentCylinder;
//磁头方向,输入 0 表示向小道号移动,1 表示向大道号移动
cout << "Please input Current Direction (0/1)(磁头方向,输入 0 表示向小道号移动,1 表示向大道号移动) :" ;
cin >> SeekDirection;
//输入磁盘请求数,请求道号
cout << "Please input Request Numbers :" ;
cin >> RequestNumber;
cout << "Please input Request cylinder string :";
Request = new int[sizeof(int) * RequestNumber]; //磁盘请求道号
Cylinder = new int[sizeof(int) * RequestNumber]; //工作柱面道号号
for (i = 0; i < RequestNumber; i++)
cin >> Request[i];
}
DiskArm::~DiskArm(){
}
//初始化道号,寻道记录
void DiskArm::InitSpace(char * MethodName)
{
int i;
cout << endl << MethodName << endl;
SeekNumber = 0;
SeekChang = 0;
for (i = 0; i < RequestNumber; i++)
Cylinder[i] = Request[i];
}

// 统计报告算法执行情况
void DiskArm::Report(void){
cout << endl;
cout << "Seek Number: " << SeekNumber << endl;
cout << "Chang Direction: " << SeekChang << endl << endl;
}
//先来先服务算法
void DiskArm::Fcfs(void)
{
int Current = CurrentCylinder;
int Direction = SeekDirection;
InitSpace("FCFS");
cout << Current;
for(int i=0; i<RequestNumber; i++){
if(((Cylinder[i] >= Current) && !Direction)
||((Cylinder[i] < Current) && Direction)){
//需要调头
SeekChang++; //调头数加 1
Direction = !Direction ; //改变方向标志
//报告当前响应的道号
cout << endl << Current << " -> " << Cylinder[i];
}
else //不需调头,报告当前响应的道号
cout << " -> " << Cylinder[i] ;
//累计寻道数,响应过的道号变为当前道号
SeekNumber += abs(Current -Cylinder[i]);
Current = Cylinder[i];
}
//报告磁盘移臂调度的情况
Report();
}
//最短寻道时间优先算法
void DiskArm::Sstf(void)
{
int Shortest;
int Distance = 999999 ;
int Direction = SeekDirection;
int Current = CurrentCylinder;
InitSpace("SSTF");
cout << Current;
for(int i=0; i<RequestNumber; i++)
{
    //查找当前最近道号
    for(int j=0; j<RequestNumber; j++)
    {
	if(Cylinder[j] == -1) continue; //-1 表示已经响应过了

	if(Distance > abs(Current-Cylinder[j]))
	{
	    //到下一道号比当前距离近,下一道号为当前距离
	    Distance = abs(Current-Cylinder[j]);
	    Shortest = j;
	}
    }
    if((( Cylinder[Shortest] >= Current) && !Direction)||(( Cylinder[Shortest] < CurrentCylinder) && Direction))
    {
	//需要调头
	SeekChang++; //调头数加 1
	Direction = !Direction ; //改变方向标志
	//报告当前响应的道号
	cout << endl << Current << " -> " << Cylinder[Shortest];
    }
    else //不需调头,报告当前响应的道号
	cout << " -> " << Cylinder[Shortest] ;
    //累计寻道数,响应过的道号变为当前道号
    SeekNumber += abs(Current -Cylinder[Shortest]);
    Current = Cylinder[Shortest];
    //恢复最近距离,销去响应过的道号
    Distance = 999999;
    Cylinder[Shortest] = -1;
}
    Report();
}
//电梯调度算法
void DiskArm::Scan(void)
{
    int Current = CurrentCylinder;
    int Direction = SeekDirection;
    InitSpace("SCAN");

    cout << Current;

    for(int i=0; i<RequestNumber; i++)
    {
        int index=-1;
        int Distance = 999999;

        for(int j=0;j<RequestNumber;j++)
	{
            if(Cylinder[j] == -1)
		continue;
            else if((Direction==0&&Cylinder[j]<Current&&(Current-Cylinder[j])<Distance) ||(Direction==1&&Cylinder[j]>Current&&(Cylinder[j]-Current)<Distance))
	    {
		    index=j;
		    Distance=abs(Current-Cylinder[j]);
            }
        }
       
        if(Direction==0)
	{
	    if(index!=-1)
	    {
		cout<<"->"<<Cylinder[index];
		SeekNumber+=Current-Cylinder[index];
		Current=Cylinder[index];
		Cylinder[index]=-1;
	    }
	    else
	    {
		cout<<"->"<<0<<endl;
		SeekNumber+=Current;
		Direction=!Direction;
		//cout<<0;
		Current=0;
		SeekChang++;
		i--;
	    }
           
        }
        else if(Direction==1)
	{
	    if(index!=-1)
	    {
		cout<<"->"<<Cylinder[index];
		SeekNumber+=Cylinder[index]-Current;
		Current=Cylinder[index];
		Cylinder[index]=-1;
	    }
	    else
	    {
		cout<<"->"<<199<<endl;
		SeekNumber+=199-Current;
		Direction=!Direction;
		//cout<<199;
		Current=199;
		SeekChang++;
		i--;
            }
        }
    }
    //报告磁盘移臂调度的情况
    Report();
}
//均匀电梯调度算法
void DiskArm::CScan(void)
{
    int Current = CurrentCylinder;
    int Direction = SeekDirection;

    InitSpace("CScan");
    cout << Current;

    for(int i=0; i<RequestNumber; i++)
    {
        int index=-1;
        int Distance = 999999;

        for(int j=0;j<RequestNumber;j++)
	{
            if(Cylinder[j]==-1)
		continue;
            else if((Direction==0 && Cylinder[j]<Current && (Current-Cylinder[j])<Distance) ||(Direction==1 && Cylinder[j] > Current && (Cylinder[j]-Current)<Distance))
	    {
                index=j;
                Distance=abs(Current-Cylinder[j]);
            }
        }
       
        if(Direction==0)
	{
	    if(index!=-1)
	    {
		cout<<"->"<<Cylinder[index];
		SeekNumber+=Current-Cylinder[index];
		Current=Cylinder[index];
		Cylinder[index]=-1;
            }
	    else
	    {
		cout<<"->"<<0<<endl;
		SeekNumber+=Current;
		Current=199;
                cout<<"0->199";
		SeekChang++;
		i--;
            }
           
        }
        else if(Direction==1)
	{
	    if(index!=-1)
	    {
		cout<<"->"<<Cylinder[index];
		SeekNumber+=Cylinder[index]-Current;
		Current=Cylinder[index];
		Cylinder[index]=-1;
	    }
	    else
	    {
		cout<<"->"<<199<<endl;
		SeekNumber+=199-Current;
		Current=0;
		SeekChang++;
		i--;
            }
        }
    }

    Report();
}

//LOOK 调度算法
void DiskArm::Lock(void)
{
    int Current = CurrentCylinder;
    int Direction = SeekDirection;
    InitSpace("Look");
    cout << Current;
       
    for(int i=0; i<RequestNumber; i++)
    {
        int index=-1;
        int Distance = 999999;
        for(int j=0;j<RequestNumber;j++)
	{
		if(Cylinder[j]==-1)
		    continue;
		else if((Direction==0&&Cylinder[j]<Current&&(Current-Cylinder[j])<Distance)||(Direction==1&&Cylinder[j]>Current&&(Cylinder[j]-Current)<Distance))
		{
		    index=j;
		    Distance=abs(Current-Cylinder[j]);
		}
        }
       
        if(Direction==0)
	{
	    if(index!=-1)
	    {
		cout<<"->"<<Cylinder[index];
		SeekNumber+=Current-Cylinder[index];
		Current=Cylinder[index];
		Cylinder[index]=-1;
	    }
	    else
	    {
		//cout<<Current<<endl;
		Direction=!Direction;
		SeekChang++;
		i--;
            }
        }
        else if(Direction==1)
	{
	    if(index!=-1)
	    {
		cout<<"->"<<Cylinder[index];
		SeekNumber+=Cylinder[index]-Current;
		Current=Cylinder[index];
		Cylinder[index]=-1;
	    }
	    else
	    {
		//cout<<Current<<endl;
		Direction=!Direction;
		SeekChang++;
		i--;
            }
        }
    }
    //报告磁盘移臂调度的情况
    Report();
}

//程序启动入口

int main(int argc,char *argv[])
{
    //建立磁盘移臂调度类
    DiskArm *dask = new DiskArm();
    //比较和分析各种调度算法的性能
    dask->Fcfs();
    dask->Sstf();
    dask->Scan();
    dask->Lock();
    dask->CScan();

}
