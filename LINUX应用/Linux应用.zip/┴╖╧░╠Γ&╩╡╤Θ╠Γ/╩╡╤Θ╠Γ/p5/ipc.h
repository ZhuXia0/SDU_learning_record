/*
* Filename
* copyright
* Function
: ipc.h
: (C) 2006 by zhonghonglie
: 声明 IPC 机制的函数原型和全局变量
*/
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/msg.h>
#define BUFSZ 256
#define MAXVAL 100
#define STRSIZ 2
#define REQUEST 1 //理发请求标识

/*信号灯控制用的共同体*/
typedef union semuns {
int val;
} Sem_uns;
/* 消息结构体*/
typedef struct msgbuf {
long mtype;
int mid;
} Msg_buf;

int wait_flg;
key_t wait_key;
int q_wait;
int sofa_flg;
key_t sofa_key;
int q_sofa;
int get_ipc_id(char *proc_file,key_t key);
char *set_shm(key_t shm_key,int shm_num,int shm_flag);
int set_msq(key_t msq_key,int msq_flag);
int set_sem(key_t sem_key,int sem_val,int sem_flag);
int down(int sem_id);
int up(int sem_id);
//互斥账本信号量
key_t a_mtx_key;
int s_account;
//同步顾客信号量
key_t c_syn_key;
int s_customer;

int sem_val;
int sem_flg;
