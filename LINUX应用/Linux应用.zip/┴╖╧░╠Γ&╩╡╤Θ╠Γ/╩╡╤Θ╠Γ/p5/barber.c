#include "ipc.h"
#include <signal.h>
#include <unistd.h>
#include <wait.h>
int main(int argc,char *argv[])
{
Sem_uns sem_arg;
struct msqid_ds msg_wait_inf;
struct msqid_ds msg_sofa_inf;
Msg_buf msg_arg;
//进程自定义的键盘中断信号处理函数
typedef void (*sighandler_t) (int);
void sigcat(){
printf("clear -s -q \n");
semctl(s_account,1,IPC_RMID,sem_arg);
semctl(s_customer,1,IPC_RMID,sem_arg);
msgctl(q_sofa, IPC_RMID,&msg_sofa_inf);
msgctl(q_wait, IPC_RMID,&msg_wait_inf);

}

a_mtx_key=202;
c_syn_key=201;
sem_flg = IPC_CREAT | 0644;
//互斥账本信号量
sem_val =1;
s_account=set_sem(a_mtx_key,sem_val,sem_flg);
//同步顾客信号量
sem_val =0;
s_customer=set_sem(c_syn_key,sem_val,sem_flg);
//建立沙发消息队列
sofa_flg = IPC_CREAT| 0644;
sofa_key = 301;
q_sofa= set_msq(sofa_key,sofa_flg);
//建立等候室消息队列
wait_flg = IPC_CREAT|0644;
wait_key = 302;
q_wait = set_msq(wait_key,wait_flg);
signal(SIGINT,(sighandler_t)sigcat);
int i;
int pid[3];
for(i=0;i<3;i++){
   pid[i]=fork();
if(pid[i]==0)
{

  while(1){  
        printf("%d号理发师睡眠。。。\n",getpid());     
     if(msgrcv(q_sofa,&msg_arg,sizeof(msg_arg),REQUEST,0) >=0)
       {//如果有消息,则消息出沙发队列(模拟一顾客理发);

           printf("%d号理发师为%d号顾客理发\n",getpid(),msg_arg.mid);              
                        up(s_customer);   
                        sleep(8);//模拟理发时间                      
                           down(s_account);//理完发,使用帐本信号量记账。互斥账本
           printf("%d号理发师收取%d号顾客交费\n",getpid(),msg_arg.mid);
                           sleep(2);//模拟交费时间
                           up(s_account);//允许下一个顾客进入
        }

     }

        }
 }
wait(NULL);
}

