#include "ipc.h"
#include <signal.h>
#include <unistd.h>
#include <wait.h>
int main(int argc,char *argv[])
{
Sem_uns sem_arg;
Msg_buf msg_arg;
struct msqid_ds msg_wait_inf;
struct msqid_ds msg_sofa_inf;
//进程自定义的键盘中断信号处理函数
typedef void (*sighandler_t) (int);
void sigcat(){
printf("clear -s -q \n");
semctl(s_account,1,IPC_RMID,sem_arg);
semctl(s_customer,1,IPC_RMID,sem_arg);
msgctl(q_sofa, IPC_RMID,&msg_sofa_inf);
msgctl(q_wait, IPC_RMID,&msg_wait_inf);
}

a_mtx_key=202;
c_syn_key=201;
sem_flg = IPC_CREAT | 0644;
//互斥账本信号量
sem_val =1;
s_account=set_sem(a_mtx_key,sem_val,sem_flg);
//同步顾客信号量
sem_val =0;
s_customer=set_sem(c_syn_key,sem_val,sem_flg);
//建立沙发消息队列
sofa_flg = IPC_CREAT| 0644;
sofa_key = 301;
q_sofa= set_msq(sofa_key,sofa_flg);
//建立等候室消息队列
wait_flg = IPC_CREAT|0644;
wait_key = 302;
q_wait = set_msq(wait_key,wait_flg);
                       
msg_arg.mtype=REQUEST;
int count;
count=1;
signal(SIGINT,(sighandler_t)sigcat);

int rate;
rate=2;//sleep 的时间
while(1)
{
   //取沙发队列的消息数，查看沙发顾客数
       int n_sofa;
        msgctl(q_sofa, IPC_STAT,&msg_sofa_inf);
        n_sofa=msg_sofa_inf.msg_qnum;
    //如果消息数小于4（沙发没座椅）
if(n_sofa<4){ //沙发没座满

      //以非阻塞方式从等待室队列接收一条消息
      //如果有消息将接收到的消息发送到沙发队列（等候室顾客做如沙发）；
      wait_flg = IPC_NOWAIT; 
if(msgrcv(q_wait,&msg_arg,sizeof(msg_arg),REQUEST,wait_flg) >= 0){
          int num;
          num=msg_arg.mid;
          msgsnd(q_sofa,&msg_arg,sizeof(msg_arg),0);
          printf("%d 号顾客从等候室坐入沙发\n",num);
       
}
else{
//否则发送一条消息到沙发队列（新来的顾客直接坐入沙发中）；
       sleep(rate);
      msg_arg.mid=count;
      msgsnd(q_sofa,&msg_arg,sizeof(msg_arg),0);
       printf("%d 号新顾客坐入沙发\n",count++);

}  

}else{         
    //沙发坐满
       //取等候室队列消息数(查等候室顾客数)
       int wait_n;
         msgctl(q_wait, IPC_STAT,&msg_wait_inf);
         wait_n=msg_wait_inf.msg_qnum;
         
       //如果消息数小于13
if(wait_n<13)
{
  //发送一条消息到等候室队列（等候室没做满，新顾客进等候室）
   int n;
   sleep(rate);
    msg_arg.mid=count;
   msgsnd(q_wait,&msg_arg,sizeof(msg_arg),0);
   printf("沙发坐满  %d 号顾客在等候室等候\n",count++);
}
else{
         //在顾客同步信号量上睡眠（等候室满。暂不接客）；
         printf("等候室满  %d 号顾客没有进入理发店\n",count++);
          down(s_customer);
         //用进程休眠一个随机时间模拟顾客到达的时间间隔。
          sleep(10);
       
}    
}
}
}
